package com.nealford.art.memento.emotherearth.test;

/**
 * User: Neal Ford
 * Date: Sep 27, 2006
 * Time: 1:50:51 PM
 * <cite>Incidentally, created by IntelliJ IDEA.</cite>
 */

import com.thoughtworks.selenium.DefaultSelenium;
import com.thoughtworks.selenium.Selenium;
import junit.framework.TestCase;

public class SeleniumRemoteControlTest extends TestCase {
	private Selenium s;

    public void setUp() {
        s = new DefaultSelenium("localhost", 4444, "*firefox", "http://localhost:8080/");
        s.start();
    }

    public void testEMotherEarthEnd2End() {
        s.open("/art_emotherearth_memento/welcome");
        s.type("user", "Homer");
        s.click("//input[@id='submitButton']");
        s.waitForPageToLoad("30000");
        assertTrue(s.getLocation().matches(".*art_emotherearth_memento/catalog"));
        assertEquals("CatalogView", s.getTitle());
        assertTrue(s.isTextPresent("Catalog of Items"));
        assertTrue(s.isElementPresent("//html/body/table/"));
        assertEquals("Ocean", s.getTable("//html/body/table/.1.1"));
        s.type("document.forms[1].quantity", "3");
        s.click("//input[@id='submit2']");
        s.waitForPageToLoad("30000");
        assertTrue(s.getLocation().matches(".*art_emotherearth_memento/showcart"));
        assertEquals("ShowCart", s.getTitle());
        assertTrue(s.isElementPresent("link=Click here for more shopping"));
        assertTrue(s.isTextPresent("*, here is your cart:"));
        s.click("link=Click here for more shopping");
        s.waitForPageToLoad("30000");
        assertTrue(s.getLocation().matches(".*art_emotherearth_memento/catalog"));
        s.type("document.forms[3].quantity", "2");
        s.click("//input[@id='submit4']");
        s.waitForPageToLoad("30000");
        s.type("ccNum", "444444444444");
        s.select("ccType", "label=Amex");
        s.type("ccExp", "12/10");
        s.click("//input[@value='Check out']");
        s.waitForPageToLoad("30000");
        assertTrue(s.isTextPresent("*, Thank you for shopping at eMotherEarth.com"));
        assertTrue(s.isTextPresent("regexp:Your confirmation number is \\d?"));
    }

    public void tearDown() {
        s.stop();
    }
}
